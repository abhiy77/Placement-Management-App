package com.hiring.placementmanagement;

import android.content.Context;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.hiring.placementmanagement.com.hiring.placementmanagement.model.Company;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class EligibleCompanyAdapter extends ArrayAdapter<Company> {
    public EligibleCompanyAdapter(Context context, ArrayList<Company> eligibleCompanies) {
        super(context, 0, eligibleCompanies);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, @NonNull ViewGroup parent) {
        // Get the data item for this position
        Company company = getItem(position);

        if (convertView == null) {
            convertView=LayoutInflater.from(getContext()).inflate(R.layout.eligible_company_list_view,parent,false);
        }
        ImageView companyImage = (ImageView)convertView.findViewById(R.id.image);
        TextView companyName=(TextView)convertView.findViewById(R.id.company_name);// only all textview need to be added
        TextView companyPackage=(TextView)convertView.findViewById(R.id.company_package);
        TextView cgpa=(TextView)convertView.findViewById(R.id.cgpa);
        TextView description=(TextView)convertView.findViewById(R.id.description);
        TextView contact=(TextView)convertView.findViewById(R.id.contact);

        assert company != null;
        companyName.setText(company.getCompanyName());
        companyPackage.setText(company.getCompanyPackage());
        cgpa.setText(company.getCGPA());
        //companyImage.setImageResource(company.getCompanyImage());
        //description.setText(company.getDescription());
        //contact.setText(company.getContactNumber());

        return convertView;
    }
}
