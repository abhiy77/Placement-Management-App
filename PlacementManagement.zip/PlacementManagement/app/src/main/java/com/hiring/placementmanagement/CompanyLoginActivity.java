package com.hiring.placementmanagement;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CompanyLoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.company_activity_login);
    }
}
